<?php

namespace Ex4;

interface SerieNumerica 
{
    public function getSiguiente();
    public function reiniciar();
    public function setComenzar($x);
}
